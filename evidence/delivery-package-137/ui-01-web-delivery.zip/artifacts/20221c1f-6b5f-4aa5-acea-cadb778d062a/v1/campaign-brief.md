# Harbour launch

Explicit synthetic campaign fixture. Audience: Hong Kong retail founders. Deliverable: editable SVG and campaign brief.
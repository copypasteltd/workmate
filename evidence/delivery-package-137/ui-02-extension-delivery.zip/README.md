# CopyPaste · 完整交付包 / Complete delivery package

任務 / Task: a0a5016c-3f29-4782-9e0f-f1b7a1277f58 · v3

工作已完成。 / Task completed.

先閱讀 result.md（如有），再開啟 artifacts/ 內的成果。manifest.json 列出每個檔案的固定版本、大小及 SHA-256；SHA256SUMS 同時覆蓋說明和清單。
Start with result.md when present, then artifacts/. manifest.json records exact file versions, sizes and SHA-256 digests. SHA256SUMS also covers these instructions and the manifest.

## 繼續編輯 / Continue editing

- 原始碼 ZIP：另行解壓至新資料夾，閱讀其 README 和 copypaste-manifest.json，按隨附依賴及執行回執處理；匯出不等於程式已通過測試。
- Source ZIPs: extract separately into a new folder; follow their README and copypaste-manifest.json, dependencies and actual execution receipts. Exporting does not certify code tests.
- SVG／PPTX：用相容編輯器開啟；字型和品牌素材的授權仍須遵守。PDF／PNG／MP4 是成果，不能據此宣稱包含可編輯工程。
- SVG/PPTX: open with a compatible editor and respect font and brand licenses. PDF/PNG/MP4 are outputs and do not imply an editable source project.
- 視頻／設計工程 JSON：使用隨附工程與素材說明。缺少的來源或尚未匯出的本機檔案不會被虛構補入。
- Video/design project JSON: follow the included project and media instructions. Missing sources and local files not submitted for delivery are not fabricated or uploaded.

需要修改時，回到原對話提供具體意見並選用這些固定版本；新的執行按原有費用確認和權限處理。下載包本身不呼叫 AI，也不建立新的 AI 費用。
For revisions, return to the original conversation with feedback and select these fixed versions. New execution uses existing cost confirmations and permissions. Exporting makes no AI call or new AI charge.

已下載的副本不會隨雲端撤回而自動刪除。 / Previously downloaded copies are not remotely erased by later source revocation.

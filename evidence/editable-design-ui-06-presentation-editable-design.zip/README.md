# Workmate · 從想法到交付

Open presentation.pptx in a compatible editor. Text, shapes, paths and chart bars remain editable.

Install fonts/CopyPasteSansTC-Regular.ttf and fonts/CopyPasteSansTC-Bold.ttf under the included OFL license. The exact original Noto Sans TC variable font is retained for provenance. Review all pages in review.html or review.pdf; these are source-based reviews.

Data mode: simulated

- PDF, PNG and HTML are rendered from the fixed source, not by PowerPoint; verify actual editor typography before final publication.
- PPTX text, primitive shapes, custom paths and chart bars/labels are editable native objects. Chart data is retained in exact CSV/source, not an embedded Excel chart.
- Install the included CopyPaste Sans TC Regular/Bold static faces, derived from the fixed Noto Sans TC source under OFL; fonts are not embedded in the PPTX.
- Raster image inputs remain raster; this tool does not infer ownership or print certification.
